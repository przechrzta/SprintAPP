package com.example.sprintapp;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;


public class DatabaseHelper extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_helper);
    }


}

